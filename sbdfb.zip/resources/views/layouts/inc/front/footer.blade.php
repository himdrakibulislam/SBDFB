<footer class="container">
 
    <div class="row footerpart-2 py-3 rounded">
         
         <div class="col-md-6 text-center ">
            <p class="my-1"><b> Powered by</b> <a href="{{url('https://www.nextondigital.com/')}}" 
                target="_blank"
                class="text-white"><b>NextOn Digital</b></a>
            </p>

            <br>
            <p><b><i class="fa-sharp fa-solid fa-laptop-code fa-1x"></i> Developed by</b> 
                <a href=""
                target="_blank"
                 class="text-white"> <b>Rakibul Islam</b> 
                </a>
            </p>
        </div>

        <div class="col-md-6">
            
            <div class="text-center">
                <a href="https://www.facebook.com/groups/1898415033764121" target="_blank" class="btn btn-success w-50 btn-sm my-1">
                    
                    <i class="fa-brands fa-facebook fa-1x me-2"></i>ফেইসবুক গ্রুপ
                </a>
                <br>
                
            
              
                <br>
            <small>
                &copy; Copyright <strong><span>SBDFB</span></strong>. All Rights Reserved
            </small>
            </div>
            
             
          </div>
    </div>
</footer>