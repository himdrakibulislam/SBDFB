@extends('layouts.front')
@section('title','পাসওয়ার্ড পরিবর্তন')
@section('content')
<div class="container adjust">
    <div class="row mb-5 ">
        <div class="col-md-2"></div>
        <div class="col-md-8 shadow my-5 text-center">
            <h3>পাসওয়ার্ড পরিবর্তন করতে চাইলে নিচে দেওয়া ফোন নম্বরে যোগাযোগ করুন।</h3>
            <a href="tel:01777244625"   class="fw-bold my-3 forgot" >01777244625</a>
            <br>
            <a href="tel:01833630039" class="fw-bold my-3 forgot" >01833630039  </a>
        </div>
        <div class="col-md-2 "></div>
    </div>
</div>
@endsection