
<?php $__env->startSection('title','Gallery'); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <div class="container">
        
            <h5 class="d-inline">Gallery</h5>
            <a href="<?php echo e(url('admin/add-gallery')); ?>" class="float-end"><i class="fa-solid fa-plus"></i></a>
        
            <div class="row">
                <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 text-center my-4">
                    
                    <img src="<?php echo e(asset($item->galleryImage)); ?>" class="w-50 rounded m-1" alt="gallery">
                    <br>



                    <form action="<?php echo e(url('admin/delete-gallery/'.$item->id)); ?>"
                        class="d-inline float-end"
                        method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>

                    <button type="submit" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></button>

                    </form>
                    


                    <a href="<?php echo e(url('admin/edit-gallery/'.$item->id)); ?>" class="btn btn-dark float-end btn-sm">
                        <i class="fa-solid fa-pen-to-square"></i>
                        </a>
                     
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\himdr\Desktop\sbdfb\resources\views\admin\gallery\index.blade.php ENDPATH**/ ?>