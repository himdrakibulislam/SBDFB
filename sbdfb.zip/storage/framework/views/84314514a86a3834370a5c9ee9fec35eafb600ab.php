
<?php $__env->startSection('title','Blood donners'); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <div class="container table-responsive">
        
        <form method="POST" action="<?php echo e(url('admin/search-user')); ?>" class="d-flex" role="search">
            <?php echo csrf_field(); ?>
            <input class="form-control me-2" name="phone" type="search" id="searchuser"  
            maxlength="11"
            placeholder="Search by contact number" aria-label="Search" required>
            <button class="btn btn-outline-success" type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
          </form>


        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">
                        নাম
                    </th>
                    <th scope="col">
                        ফোন নাম্বার
                    </th>
                    <th scope="col">
                        রক্তের গ্রুপ
                    </th>
                    <th scope="col">
                        
                    </th>
                </tr>
            </thead>
            <tbody>
               <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                       
                        <td  scope="row"><?php echo e($user->name); ?> </td>
                        <td  scope="row"><a href="tel:<?php echo e($user->phone); ?>"><?php echo e($user->phone); ?></a></td>
                        <td  scope="row"><?php echo e($user->blood_group); ?> <small><?php echo e($user->donation_type); ?></small></td>
                        <td>
                            

                            <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                                <i class="fa-solid fa-ellipsis-vertical fa-2x"></i>
                                
                              </a>
                    
                              <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">

                               
                               <li class="notification-item">
                                <a href="<?php echo e(url('admin/user/'.$user->id)); ?>"
                                    class="btn btn-outline-success btn-sm w-100"
                                    >view</a>
                               </li>
                               <li>
                                <hr class="dropdown-divider">
                              </li>


                               

                               <li class="notification-item ">
                                <a href="edit" 
                                class="btn btn-outline-success btn-sm w-100"
                                ><i class="fa-solid fa-pen-to-square"></i></a>
                               </li>
                               <li>
                                <hr class="dropdown-divider">
                              </li>


                               <li class="notification-item ">
                                <a href="delete" class="btn btn-outline-success btn-sm w-100"><i class="fa-solid fa-trash"></i></a>
                               </li>



                               <li class="notification-item">
                                <form action="<?php echo e(url('admin/user/add-admin/'.$user->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" 
                                        class="btn btn-outline-success btn-sm w-100"
                                        >Make Admin
                                    </button>
                                </form>
                               </li>
                               <li>
                                <hr class="dropdown-divider">
                              </li>

                              </ul>
                        </td>
                        
                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        
        
    </div>
    <?php echo e($users->links()); ?>

</main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\himdr\Desktop\sbdfb\resources\views\admin\user\blood.blade.php ENDPATH**/ ?>