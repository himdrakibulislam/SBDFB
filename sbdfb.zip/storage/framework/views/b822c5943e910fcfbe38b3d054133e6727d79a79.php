
<?php $__env->startSection('title','Edit Gallery'); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <div class="container">
            <h5 class="d-inline">Edit Gallery</h5>
            <a href="<?php echo e(url('admin/gallery')); ?>" class="float-end">Back</a>
           <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6 my-5">
                <img id="galleryPreview" src="<?php echo e(asset($gallery->galleryImage)); ?>" class="w-50">
                <form action="<?php echo e(url('admin/update-gallery/'.$gallery->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <label>Upload Gallery Image</label>
                    <input 
                    type="file" 
                    name="galleryImage"
                    class="form-control <?php $__errorArgs = ['galleryImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                    id="gallery">
                    <?php $__errorArgs = ['galleryImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                    <button type="submit" class="btn btn-dark my-3 w-50 float-end">Upload</button>
                </form>
            </div>
            <div class="col-md-3"></div>
           </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-scripts'); ?>
    <script>
        $(document).ready(()=>{
      $('#gallery').change(function(){
        const file = this.files[0];
        if (file){
          let reader = new FileReader();
          reader.onload = function(event){
            $('#galleryPreview').attr('src', event.target.result);
          }
          reader.readAsDataURL(file);
        }
      });
    });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\himdr\Desktop\sbdfb\resources\views\admin\gallery\edit.blade.php ENDPATH**/ ?>