
<?php $__env->startSection('title','Admins'); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <div class="container table-responsive">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th scope="col">
                        নাম
                    </th>
                    <th scope="col">
                        ফোন নাম্বার
                    </th>
                    <th scope="col">
                        রক্তের গ্রুপ
                    </th>
                    <th scope="col">
                        
                    </th>
                </tr>
            </thead>
            <tbody>
               <?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                       
                        <td  scope="row"><?php echo e($admin->name); ?> 
                            <span class="badge bg-success mx-2 float-end">Admin</span>
                        </td>
                        <td  scope="row"><a href="tel:<?php echo e($admin->phone); ?>"><?php echo e($admin->phone); ?></a></td>
                        <td  scope="row"><?php echo e($admin->blood_group); ?></td>
                        <td>


                            <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                                <i class="fa-solid fa-ellipsis-vertical fa-2x"></i>
                                
                              </a>
                    
                              <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">

                               
                               <li class="notification-item">
                                <a href="<?php echo e(url('admin/user/'.$admin->id)); ?>"
                                    class="btn btn-outline-success btn-sm w-100"
                                    >view</a>
                               </li>
                               <li>
                                <hr class="dropdown-divider">
                              </li>


                              



                               <li class="notification-item ">
                                <a href="edit" 
                                class="btn btn-outline-success btn-sm w-100"
                                ><i class="fa-solid fa-pen-to-square"></i></a>
                               </li>
                               <li>
                                <hr class="dropdown-divider">
                              </li>


                               <li class="notification-item ">
                                <a href="delete" class="btn btn-outline-success btn-sm w-100"><i class="fa-solid fa-trash"></i></a>
                               </li>


                               <li class="notification-item">
                                <form action="<?php echo e(url('admin/user/remove-admin/'.$admin->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" 
                                        class="btn btn-outline-success btn-sm w-100"
                                        >Remove Admin
                                    </button>
                                </form>
                               </li>
                               <li>
                                <hr class="dropdown-divider">
                              </li>



                              </ul>
                        </td>
                        
                </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\himdr\Desktop\sbdfb\resources\views\admin\user\admin.blade.php ENDPATH**/ ?>