
<?php $__env->startSection('title','users'); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <div class="container">
        <?php if(is_object($user)): ?>

        <div class="row">
         <div class="col-md-2"></div>
         <div class="col-md-8 ">
           <div class="text-center">
            <?php if($user->profile_url): ?>
            <img src="<?php echo e(asset($user->profile_url)); ?>" alt="user" class="allusers" >
            <?php else: ?>
            <img src="<?php echo e(asset('assets/img/user.png')); ?>" alt="user" class="rounded-circle" style="width:20%">
            <?php endif; ?>
            <h4 class="my-2"><?php echo e($user->name); ?></h4>
            <a href="<?php echo e(url('admin/edit-password/'.$user->id)); ?>"
              class="btn btn-outline-dark my-3 w-50"
              >
            Edit Password
            </a>
           </div>

           <div class="row">
             <div class="col-md-6">
                <p><i class="fa-solid fa-phone mx-3"></i><a href="tel:<?php echo e($user->phone); ?>"><?php echo e($user->phone); ?></a></p>

                <p><i class="fa-solid fa-location-dot mx-3"></i><?php echo e($user->address); ?></p>
                <p><i class="fa-solid fa-location-dot mx-3"></i><?php echo e($user->district); ?></p>

                <p><i class="fa-solid fa-droplet mx-3"></i><?php echo e($user->blood_group); ?></p>
                
                
            
             </div>


             <div class="col-md-6">
                <p><i class="fa-solid fa-user mx-3"></i><?php echo e($user->gender); ?></p>
                
                <?php if($user->email): ?>
                <p><i class="fa-solid fa-envelope mx-3"></i><?php echo e($user->email); ?></p>
                    
                <?php endif; ?>


                <p class="border rounded border-dark">
                  <b class="ms-4">সর্বশেষ রক্তদান</b>
                  <br>
                  <i class="fa-solid fa-calendar-days mx-3"></i><?php echo e(date('d / F / Y',strtotime($user->last_donated))); ?></p>

                  <p> <b>অনুদানের ধরণ </b>: 
                    <?php echo e($user->donation_type); ?>

                  </p>
             </div>
           </div>

         </div>
         <div class="col-md-2"></div>
         <div class="col-md-3">
         <form action="<?php echo e(url('admin/user/delete/'.$user->id)); ?>"
         method="POST"
         >
         <?php echo csrf_field(); ?>
         <?php echo method_field('delete'); ?>
         <button type="submit"
          class="btn btn-outline-danger w-100 float-end"
          >Delete User</button>

        </form>
        </div>   
        </div>

     

        <?php else: ?>
        <h3 class="text-center my-4"><?php echo e($user); ?></h3>
        <?php endif; ?>
       
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\himdr\Desktop\sbdfb\resources\views\admin\user\view.blade.php ENDPATH**/ ?>