
<?php $__env->startSection('title','users'); ?>
<?php $__env->startSection('content'); ?>
<main id="main" class="main">
    <div class="container">
        <?php if(is_object($user)): ?>

        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6">
              <div class="text-center">
               <?php if($user->profile_url): ?>
               <img src="<?php echo e(asset($user->profile_url)); ?>" alt="user" class="allusers" >
               <?php else: ?>
               <img src="<?php echo e(asset('assets/img/user.png')); ?>" alt="user" class="rounded-circle" style="width:20%">
               <?php endif; ?>
               <h4 class="my-3"><?php echo e($user->name); ?></h4>
               <form action="<?php echo e(url('admin/update-password/'.$user->id)); ?>" method="POST">

                <?php echo csrf_field(); ?>
                <input type="password" name="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Password" required >
 
                
                 <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                <button type="submit" class="btn btn-outline-dark float-end my-2 w-50">Update</button>
               </form>
            </div>
            <div class="col-md-3"></div>
                <?php else: ?>
                <h3 class="text-center my-5 fw-bold">User Not Found</h3>
                <?php endif; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\himdr\Desktop\sbdfb\resources\views\admin\user\edit-password.blade.php ENDPATH**/ ?>