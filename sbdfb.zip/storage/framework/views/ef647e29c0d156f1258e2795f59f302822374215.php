
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('content'); ?>
    
  <main id="main" class="main">

    
    <h3>Dashboard</h3>
    <div class="row">
      <div class="col-md-3 bg-success text-white rounded text-center py-3 me-2 mt-3">
        <h3>All Donors</h3>
        <small class="total"><?php echo e($alldonners); ?></small>
      </div>
      <div class="col-md-4  bg-danger text-white rounded text-center py-3 me-2 mt-3">
        <h3>Blood Donors</h3>
        <small class="total"><?php echo e($blood); ?></small> 
      </div>
      <div class="col-md-3 bg-secondary text-white rounded text-center py-3 me-2 mt-3">
          <h3>Platelets Donors</h3>
           <small class="total"><?php echo e($platelets); ?></small>
      </div>
    </div>

  </main><!-- End #main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\himdr\Desktop\sbdfb\resources\views\admin\dashboard.blade.php ENDPATH**/ ?>